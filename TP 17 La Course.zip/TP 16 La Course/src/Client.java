
public class Client {
	public static void main(String[] args) {

		Jeu jeu = new Jeu();	
		jeu.jouerPartie();
	}
}