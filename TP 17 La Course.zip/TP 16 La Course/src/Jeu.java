public class Jeu {
    
    private int positionPion;
    private Plateau plateau;
    
    public Jeu() {
        this.positionPion = 0;
        this.plateau = new Plateau();
    }

	private void setPositionPion(int positionPion) {
		this.positionPion = positionPion;
	}
	
	private static int lancerDe() {
		return (int) (6.0 * Math.random() + 1.0);
	}
	
	public void jouerPartie() {
		while (!estPartieFinie()) {
			jouerPion();
		}
	}
	
	private boolean estPartieFinie() {
		return (this.positionPion==Plateau.NB_CASES- 1);
	}
	
	private void jouerPion() {
		setPositionPion(this.positionPion+plateau.calculDeplacement(this.positionPion,lancerDe()));
	}
}